import React from "react";
import LoginRegister from "./components/LoginRegister";

function App() {
  return (
    <LoginRegister></LoginRegister>
  );
}

export default App;
